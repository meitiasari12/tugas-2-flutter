package com.example.meiapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
